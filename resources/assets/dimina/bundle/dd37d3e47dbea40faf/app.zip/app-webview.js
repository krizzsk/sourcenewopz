void function() {
  

  

  

  Foundation && Foundation.refreshDDConfig && Foundation.refreshDDConfig({
  "pages": [
    "pages/index",
    "pages/example",
    "pages/webview",
    "pages/bill/index",
    "pages/bill/search",
    "pages/bill/barcode",
    "pages/bill/amount",
    "pages/bill/payInfo",
    "pages/bill/payDetail",
    "pages/bill/list",
    "pages/recharge/index",
    "pages/recharge/carrier",
    "pages/recharge/packagelist",
    "pages/giftcard/package-list",
    "pages/giftcard/card-list",
    "pages/giftcard/detail",
    "pages/giftcard/index"
  ],
  "global": {
    "window": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show"
    }
  },
  "subpackagesDir": {
    "__APP__": "app"
  },
  "subpackages": [],
  "subPackages": [],
  "entryPagePath": "pages/index",
  "page": {
    "pages/index": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "usingComponents": {
        "nav-bar": "/components/index61353e7a/index"
      }
    },
    "pages/example": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "usingComponents": {
        "nav-bar": "/components/index61353e7a/index",
        "list": "/components/list4e86696a/index",
        "vant-test": "/components/vant-test4a8f5ecf/index",
        "store-test": "/components/store-test781e182b/index",
        "i18n-test": "/components/i18n-testcabaa5fc/index",
        "webview-test": "/components/webview-test50462e93/index",
        "xfetch-test": "/components/xfetch-test2e43a044/index",
        "request-test": "/components/request4d885830/index",
        "bridge-test": "/components/bridge4bc68f36/index",
        "bill-picker-test": "/components/bill-picker-test6ba3ccd8/index"
      }
    },
    "pages/webview": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "usingComponents": {}
    },
    "pages/bill/index": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "usingComponents": {
        "bill-search": "/components/bill-search088d1640/index",
        "bill-category": "/components/bill-category6b520256/index",
        "nav-bar": "/components/index61353e7a/index",
        "bill-nav-history": "/components/bill-nav-history33080100/index",
        "van-notice-bar": "/components/vant/weapp564a9674/notice-bar/index"
      }
    },
    "pages/bill/search": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "usingComponents": {
        "bill-cell": "/components/bill-cellc330a58c/index",
        "nav-bar": "/components/index61353e7a/index",
        "bill-bebeing": "/components/bill-bebeing8338031c/index",
        "bill-recommend": "/components/bill-recommendad61fddc/index"
      }
    },
    "pages/bill/barcode": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "component": true,
      "usingComponents": {
        "nav-bar": "/components/index61353e7a/index",
        "bill-popup": "/components/bill-popupa9656efc/index",
        "bill-button": "/components/bill-button484502ca/index",
        "bill-toast": "/components/bill-toast409f8f06/index",
        "van-icon": "/components/vant/weapp564a9674/icon/index",
        "bill-progress": "/components/bill-progress7cafd805/index",
        "bill-history-scroll": "/components/bill-history-scroll119d3ebe/index",
        "bill-barcode-popup-bottom": "/components/bill-barcode-popup-bottom9b37961e/index",
        "bill-popup-bottom": "/components/bill-popup-bottom05efaf78/index"
      }
    },
    "pages/bill/amount": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "component": true,
      "usingComponents": {
        "nav-bar": "/components/index61353e7a/index",
        "van-field": "/components/vant/weapp564a9674/field/index",
        "bill-button": "/components/bill-button484502ca/index"
      }
    },
    "pages/bill/payInfo": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "component": true,
      "usingComponents": {
        "nav-bar": "/components/index61353e7a/index",
        "bill-image": "/components/bill-imagec8a0dc9e/index",
        "bill-button": "/components/bill-button484502ca/index",
        "bill-toast": "/components/bill-toast409f8f06/index",
        "van-icon": "/components/vant/weapp564a9674/icon/index",
        "bill-coupon-card": "/components/bill-coupon-card0b1d6126/index",
        "package-questions": "/components/package-questions7c0b95d9/index"
      }
    },
    "pages/bill/payDetail": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "component": true,
      "usingComponents": {
        "nav-bar": "/components/index61353e7a/index",
        "bill-popup": "/components/bill-popupa9656efc/index",
        "bill-button": "/components/bill-button484502ca/index",
        "bill-toast": "/components/bill-toast409f8f06/index",
        "bill-popup-bottom": "/components/bill-popup-bottom05efaf78/index",
        "bill-circle-loading": "/components/bill-circle-loading18a8dd57/index",
        "bill-activity-popup": "/components/bill-activity-popup72e6ad06/index",
        "package-questions": "/components/package-questions7c0b95d9/index"
      }
    },
    "pages/bill/list": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "component": true,
      "usingComponents": {
        "layout-list": "/components/list207b9cec/index",
        "bill-list-card": "/components/bill-list-card5810c5b5/index",
        "bill-list-tab": "/components/bill-list-tab74a3f73e/index",
        "bill-toast": "/components/bill-toast409f8f06/index",
        "bill-popup-bottom": "/components/bill-popup-bottom05efaf78/index",
        "bill-picker": "/components/bill-picker43a053b4/index",
        "bill-list-cell": "/components/bill-list-cell21dd5b07/index",
        "bill-bebeing": "/components/bill-bebeing8338031c/index"
      }
    },
    "pages/recharge/index": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "component": true,
      "usingComponents": {
        "van-button": "/components/vant-weappfdcc1572/button/index",
        "van-overlay": "/components/vant/weapp564a9674/overlay/index",
        "van-field": "/components/vant-weappfdcc1572/field/index",
        "van-cell-group": "/components/vant-weappfdcc1572/cell-group/index",
        "van-toast": "/components/vant-weappfdcc1572/toast/index",
        "nav-bar": "/components/index61353e7a/index",
        "type-list": "/components/type-listda7c1ffa/index",
        "phone-input": "/components/phone-input280868c6/index",
        "bill-button": "/components/bill-button359e462a/index"
      }
    },
    "pages/recharge/carrier": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "component": true,
      "usingComponents": {
        "nav-bar": "/components/index61353e7a/index",
        "layout-list": "/components/list207b9cec/index"
      }
    },
    "pages/recharge/packagelist": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "component": true,
      "usingComponents": {
        "nav-bar": "/components/index61353e7a/index",
        "popup-bottom": "/components/popup-bottom10464fe8/index",
        "package-list-cell": "/components/package-list-cell30f48d9c/index",
        "package-questions": "/components/package-questions7c0b95d9/index",
        "bill-button": "/components/bill-button359e462a/index",
        "van-icon": "/components/vant/weapp564a9674/icon/index",
        "faq-title": "/components/faq-title7a9e1cb4/index"
      }
    },
    "pages/giftcard/package-list": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "component": true,
      "usingComponents": {
        "nav-bar": "/components/index61353e7a/index",
        "package-cell": "/components/package-cell0914cf9e/index",
        "van-icon": "/components/vant/weapp564a9674/icon/index",
        "price-popup": "/components/price-popupbd2b873e/index",
        "bill-circle-loading": "/components/bill-circle-loading18a8dd57/index",
        "package-questions": "/components/package-questions7c0b95d9/index",
        "faq-title": "/components/faq-title7a9e1cb4/index"
      }
    },
    "pages/giftcard/card-list": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "component": true,
      "usingComponents": {
        "layout-list": "/components/list207b9cec/index",
        "bill-bebeing": "/components/bill-bebeing8338031c/index"
      }
    },
    "pages/giftcard/detail": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "component": true,
      "usingComponents": {
        "van-sticky": "/components/vant/dist/sticky/index",
        "bill-toast": "/components/bill-toast409f8f06/index",
        "van-icon": "/components/vant/weapp564a9674/icon/index",
        "nav-bar": "/components/index61353e7a/index",
        "package-questions": "/components/package-questions7c0b95d9/index"
      }
    },
    "pages/giftcard/index": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "usingComponents": {
        "nav-bar": "/components/index61353e7a/index",
        "layout-list": "/components/list207b9cec/index",
        "van-icon": "/components/vant/weapp564a9674/icon/index",
        "api-loading": "/components/api-loading621ecd42/index"
      }
    }
  }
});

}();
