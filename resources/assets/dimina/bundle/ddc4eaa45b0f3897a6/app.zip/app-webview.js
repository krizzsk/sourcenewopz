void function() {
  

  

  

  Foundation && Foundation.refreshDDConfig && Foundation.refreshDDConfig({
  "pages": [
    "pages/index",
    "pages/webview",
    "pages/bill/list",
    "pages/giftcard/detail",
    "pages/giftcard/card-list",
    "pages/bill/payDetail",
    "pages/giftcard/index",
    "pages/giftcard/package-list"
  ],
  "global": {
    "window": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show"
    }
  },
  "subpackagesDir": {
    "__APP__": "app"
  },
  "subpackages": [],
  "subPackages": [],
  "entryPagePath": "pages/index",
  "page": {
    "pages/index": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "usingComponents": {
        "nav-bar": "/components/indexc0adbb64/index"
      }
    },
    "pages/webview": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "usingComponents": {}
    },
    "pages/bill/list": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "component": true,
      "usingComponents": {
        "layout-list": "/components/list3c188336/index",
        "bill-list-card": "/components/bill-list-card21f0ba61/index",
        "bill-list-tab": "/components/bill-list-tab51dcbd12/index",
        "bill-toast": "/components/bill-toastc28539ae/index",
        "bill-popup-bottom": "/components/bill-popup-bottom6201e418/index",
        "bill-picker": "/components/bill-picker00c800fa/index",
        "bill-list-cell": "/components/bill-list-cell2885609a/index",
        "bill-bebeing": "/components/bill-bebeing225da3c4/index"
      }
    },
    "pages/giftcard/detail": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "component": true,
      "usingComponents": {
        "van-sticky": "/components/vant/dist/sticky/index",
        "bill-toast": "/components/bill-toastc28539ae/index",
        "van-icon": "/components/vant/weapp05bd39c0/icon/index",
        "nav-bar": "/components/indexc0adbb64/index"
      }
    },
    "pages/giftcard/card-list": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "component": true,
      "usingComponents": {
        "layout-list": "/components/list3c188336/index",
        "bill-bebeing": "/components/bill-bebeing225da3c4/index"
      }
    },
    "pages/bill/payDetail": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "component": true,
      "usingComponents": {
        "nav-bar": "/components/indexc0adbb64/index",
        "bill-popup": "/components/bill-popup6a5a732e/index",
        "bill-button": "/components/bill-button6add2d9e/index",
        "bill-toast": "/components/bill-toastc28539ae/index",
        "bill-popup-bottom": "/components/bill-popup-bottom6201e418/index",
        "bill-circle-loading": "/components/bill-circle-loading2622f42b/index",
        "van-icon": "/components/vant/weapp05bd39c0/icon/index",
        "bill-activity-popup": "/components/bill-activity-popupff3e784c/index"
      }
    },
    "pages/giftcard/index": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "usingComponents": {
        "layout-list": "/components/list3c188336/index",
        "gift-card-tips": "/components/gift-card-tips8d8bb78e/index",
        "bill-popup-bottom": "/components/bill-popup-bottom6201e418/index",
        "van-icon": "/components/vant/weapp05bd39c0/icon/index",
        "api-loading": "/components/api-loading578523d4/index"
      }
    },
    "pages/giftcard/package-list": {
      "navigationBarBackgroundColor": "#ffffff",
      "navigationBarTextStyle": "black",
      "navigationBarTitleText": "",
      "navigationStyle": "custom",
      "backgroundColor": "#ffffff",
      "backgroundTextStyle": "dark",
      "backgroundColorTop": "#ffffff",
      "backgroundColorBottom": "#ffffff",
      "enablePullDownRefresh": false,
      "onReachBottomDistance": 50,
      "pageOrientation": "portrait",
      "capsuleButton": "show",
      "component": true,
      "usingComponents": {
        "nav-bar": "/components/indexc0adbb64/index",
        "package-cell": "/components/package-cell4a6b6d6c/index",
        "van-icon": "/components/vant/weapp05bd39c0/icon/index",
        "price-popup": "/components/price-popup1388dd35/index",
        "bill-popup-bottom": "/components/bill-popup-bottom6201e418/index",
        "bill-circle-loading": "/components/bill-circle-loading2622f42b/index",
        "info-entry-popup": "/components/info-entry-popup0775039a/index",
        "package-questions": "/components/package-questions936d56f6/index",
        "faq-title": "/components/faq-title39ab4760/index",
        "ibg-buttom": "/components/ibg-button530a5cb2/index"
      }
    }
  }
});

}();
